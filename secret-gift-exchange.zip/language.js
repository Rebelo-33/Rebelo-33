// language.js
// Language translation logic (already provided in previous steps)